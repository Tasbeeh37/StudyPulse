import SwiftUI

extension Color {

    static let burgundy = Color(
        red: 0.45,
        green: 0.05,
        blue: 0.12
    )
}
