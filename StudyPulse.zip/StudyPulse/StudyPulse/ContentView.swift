import SwiftUI

struct ContentView: View {

    @State private var model = StudyPulseModel()

    @State private var showProfileSheet = false

    var body: some View {

        TabView {

            TodayView(
                model: model,
                showProfileSheet: $showProfileSheet
            )
            .tabItem {
                Label(
                    "Today",
                    systemImage: "checkmark.circle"
                )
            }

            ProgressViewPage(
                model: model,
                showProfileSheet: $showProfileSheet
            )
            .tabItem {
                Label(
                    "Progress",
                    systemImage: "chart.bar.fill"
                )
            }

            NotesView(
                model: model,
                showProfileSheet: $showProfileSheet
            )
            .tabItem {
                Label(
                    "Notes",
                    systemImage: "note.text"
                )
            }

            CalendarView(
                model: model,
                showProfileSheet: $showProfileSheet
            )
            .tabItem {
                Label(
                    "Calendar",
                    systemImage: "calendar"
                )
            }
        }

        .tint(.burgundy)

        .sheet(isPresented: $showProfileSheet) {

            ProfileView(
                model: model
            )
        }
    }
}

#Preview {
    ContentView()
}
