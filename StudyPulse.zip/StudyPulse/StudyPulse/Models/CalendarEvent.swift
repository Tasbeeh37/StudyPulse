import Foundation

enum EventType: String, CaseIterable {
    case assessment = "Assessment"
    case meeting = "Meeting"
    case deadline = "Deadline"
    case project = "Project"
}

struct CalendarEvent: Identifiable {
    let id = UUID()
    var title: String
    var type: EventType
    var date: Date
}
