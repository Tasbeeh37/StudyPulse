import Foundation
struct HabitItem: Identifiable {
    let id = UUID()
    var title: String
    var tag: String
    var isCompleted: Bool
}
