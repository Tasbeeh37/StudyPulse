import Foundation
struct StudyNoteItem: Identifiable {
    let id = UUID()
    var title: String
    var subtitle: String
    var tag: String
    var tagColor: NoteTagType
    var dateText: String
    var isCompleted: Bool
}

enum NoteTagType: String, CaseIterable {
    case all = "All"
    case goals = "Goals"
    case deadlines = "Deadlines"
    case keyConcepts = "Key Concepts"
}
