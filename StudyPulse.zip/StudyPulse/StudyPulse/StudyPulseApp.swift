import SwiftUI

@main
struct StudyPulseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
