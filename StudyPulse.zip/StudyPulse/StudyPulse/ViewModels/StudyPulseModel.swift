import Foundation
import Observation

@Observable
class StudyPulseModel {

    var habits: [HabitItem] = [

        HabitItem(
            title: "Review iOS Architecture & SwiftUI",
            tag: "Dev",
            isCompleted: true
        ),

        HabitItem(
            title: "Solve 2 LeetCode Algorithms",
            tag: "Logic",
            isCompleted: true
        ),

        HabitItem(
            title: "Read 20 pages of Clean Code...",
            tag: "Reading",
            isCompleted: true
        ),

        HabitItem(
            title: "Evening 30-min Workout",
            tag: "Fitness",
            isCompleted: false
        ),

        HabitItem(
            title: "Prepare tomorrow's study schedule...",
            tag: "Prep",
            isCompleted: false
        )
    ]

    var notes: [StudyNoteItem] = [

        StudyNoteItem(
            title: "SwiftUI State Management Deep Dive",
            subtitle:
                "Master @Observable, environment, and navigation bindings for macOS and iOS apps.",
            tag: "Goal • Due Friday",
            tagColor: .goals,
            dateText: "Today, 2:30 PM",
            isCompleted: false
        ),

        StudyNoteItem(
            title: "Algorithms Exam: Binary Search Trees & Graphs",
            subtitle:
                "Review Dijkstra, topological sorting, and balanced AVL rotation mechanics.",
            tag: "Deadline • 28 Sep",
            tagColor: .deadlines,
            dateText: "Yesterday",
            isCompleted: false
        ),

        StudyNoteItem(
            title: "Read Human Interface Guidelines (HIG) Navigation",
            subtitle:
                "Explored modal sheets, hierarchical split-views, and tactile spring feedback.",
            tag: "Reading • Completed",
            tagColor: .keyConcepts,
            dateText: "23 Sep",
            isCompleted: true
        )
    ]

    var currentStreak: Int = 5

    private var hasIncrementedToday: Bool = false

    var events: [CalendarEvent] = [

        CalendarEvent(
            title: "iOS Midterm Exam",
            type: .assessment,
            date: Date().addingTimeInterval(86400 * 3)
        ),

        CalendarEvent(
            title: "Group Project Meeting",
            type: .meeting,
            date: Date().addingTimeInterval(86400 * 1)
        ),

        CalendarEvent(
            title: "StudyPulse Submission",
            type: .project,
            date: Date().addingTimeInterval(86400 * 5)
        )
    ]

    var isLoggedIn: Bool = false

    var username: String = ""

    func addHabit(title: String) {

        let trimmedTitle = title.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !trimmedTitle.isEmpty else {
            return
        }

        habits.append(
            HabitItem(
                title: trimmedTitle,
                tag: "Custom",
                isCompleted: false
            )
        )
    }

    func deleteHabit(_ habit: HabitItem) {

        habits.removeAll {
            $0.id == habit.id
        }
    }

    func toggleHabit(_ habit: HabitItem) {

        guard let index = habits.firstIndex(
            where: { $0.id == habit.id }
        ) else {
            return
        }

        habits[index].isCompleted.toggle()

        checkForFullCompletion()
    }

    private func checkForFullCompletion() {

        let allCompleted = !habits.isEmpty && habits.allSatisfy { $0.isCompleted }

        if allCompleted && !hasIncrementedToday {
            currentStreak += 1
            hasIncrementedToday = true
        } else if !allCompleted {
            hasIncrementedToday = false
        }
    }

    func addNote(title: String) {

        let trimmedTitle = title.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !trimmedTitle.isEmpty else {
            return
        }

        notes.append(
            StudyNoteItem(
                title: trimmedTitle,
                subtitle: "Added today.",
                tag: "Goal",
                tagColor: .goals,
                dateText: "Just now",
                isCompleted: false
            )
        )
    }

    func deleteNote(_ note: StudyNoteItem) {

        notes.removeAll {
            $0.id == note.id
        }
    }

    func toggleNote(_ note: StudyNoteItem) {

        guard let index = notes.firstIndex(
            where: { $0.id == note.id }
        ) else {
            return
        }

        notes[index].isCompleted.toggle()
    }

    func addEvent(title: String, type: EventType, date: Date) {

        let trimmedTitle = title.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !trimmedTitle.isEmpty else {
            return
        }

        events.append(
            CalendarEvent(
                title: trimmedTitle,
                type: type,
                date: date
            )
        )
    }

    func deleteEvent(_ event: CalendarEvent) {

        events.removeAll {
            $0.id == event.id
        }
    }

    func login(username: String) {

        let trimmedUsername = username.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !trimmedUsername.isEmpty else {
            return
        }

        self.username = trimmedUsername

        self.isLoggedIn = true
    }

    func logout() {
        username = ""
        isLoggedIn = false
    }
}
