import SwiftUI

struct CalendarView: View {

    var model: StudyPulseModel
    @Binding var showProfileSheet: Bool

    @State private var newEventTitle = ""
    @State private var selectedType: EventType = .assessment
    @State private var selectedDate = Date()
    @State private var showAddEvent = false

    var sortedEvents: [CalendarEvent] {
        model.events.sorted { $0.date < $1.date }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("STUDYPULSE")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundStyle(.gray)
                            Text("Calendar")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        }
                        Spacer()
                        HStack(spacing: 12) {
                            Button {
                                showProfileSheet = true
                            } label: {
                                Image(systemName: "person.crop.circle.fill")
                                    .font(.title2)
                                    .foregroundStyle(Color.burgundy)
                            }
                        }
                    }
                    .padding(.horizontal)

                    Button {
                        showAddEvent.toggle()
                    } label: {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("Add Deadline or Event")
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.burgundy)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .padding(.horizontal)

                    if showAddEvent {
                        VStack(spacing: 10) {

                            TextField("Event title...", text: $newEventTitle)
                                .padding()
                                .background(Color(.systemGray6))
                                .clipShape(RoundedRectangle(cornerRadius: 10))

                            Picker("Type", selection: $selectedType) {
                                ForEach(EventType.allCases, id: \.self) { type in
                                    Text(type.rawValue).tag(type)
                                }
                            }
                            .pickerStyle(.segmented)

                            DatePicker(
                                "Date",
                                selection: $selectedDate,
                                displayedComponents: .date
                            )

                            Button {
                                model.addEvent(
                                    title: newEventTitle,
                                    type: selectedType,
                                    date: selectedDate
                                )
                                newEventTitle = ""
                                showAddEvent = false
                            } label: {
                                Text("Save Event")
                                    .fontWeight(.semibold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.burgundy)
                                    .foregroundStyle(.white)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                        }
                        .padding()
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .padding(.horizontal)
                    }

                    if sortedEvents.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "calendar")
                                .font(.system(size: 40))
                                .foregroundStyle(Color(.systemGray3))
                            Text("No upcoming events")
                                .font(.headline)
                                .foregroundStyle(.gray)
                            Text("Tap above to add your first deadline or meeting.")
                                .font(.caption)
                                .foregroundStyle(Color(.systemGray3))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 30)
                    } else {
                        VStack(spacing: 10) {
                            ForEach(sortedEvents) { event in
                                HStack {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(event.title)
                                            .font(.subheadline)
                                            .fontWeight(.semibold)

                                        Text(event.date.formatted(date: .abbreviated, time: .omitted))
                                            .font(.caption)
                                            .foregroundStyle(.gray)
                                    }

                                    Spacer()

                                    Text(event.type.rawValue)
                                        .font(.caption2)
                                        .fontWeight(.semibold)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 4)
                                        .background(Color.burgundy.opacity(0.15))
                                        .foregroundStyle(Color.burgundy)
                                        .clipShape(RoundedRectangle(cornerRadius: 8))

                                    Button {
                                        model.deleteEvent(event)
                                    } label: {
                                        Image(systemName: "trash")
                                            .font(.subheadline)
                                            .foregroundStyle(.red.opacity(0.8))
                                            .padding(.leading, 6)
                                    }
                                }
                                .padding()
                                .background(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .shadow(color: .black.opacity(0.02), radius: 3, x: 0, y: 2)
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}
