import SwiftUI

struct NotesView: View {

    var model: StudyPulseModel

    @Binding var showProfileSheet: Bool

    @State private var newNoteTitle = ""

    @State private var selectedFilter: NoteTagType = .all

    var filteredNotes: [StudyNoteItem] {
        if selectedFilter == .all {
            return model.notes
        }
        return model.notes.filter { $0.tagColor == selectedFilter }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("STUDYPULSE")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundStyle(.gray)
                            Text("Notes")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        }

                        Spacer()

                        HStack(spacing: 12) {
                            Button {
                                showProfileSheet = true
                            } label: {
                                Image(systemName: "person.crop.circle.fill")
                                    .font(.title2)
                                    .foregroundStyle(Color.burgundy)
                            }
                        }
                    }
                    .padding(.horizontal)

                    HStack {
                        Image(systemName: "square.and.pencil")
                            .foregroundStyle(.gray)

                        TextField("Add study goal or reminder...", text: $newNoteTitle)

                        Button {
                            model.addNote(title: newNoteTitle)
                            newNoteTitle = ""
                        } label: {
                            Image(systemName: "plus")
                                .foregroundStyle(.white)
                                .padding(10)
                                .background(Color.burgundy)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .padding(.horizontal)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(NoteTagType.allCases, id: \.self) { filter in
                                Button {
                                    selectedFilter = filter
                                } label: {
                                    Text(filter.rawValue)
                                        .font(.subheadline)
                                        .fontWeight(.semibold)
                                        .padding(.horizontal, 16)
                                        .padding(.vertical, 8)
                                        .background(selectedFilter == filter ? Color.burgundy : Color(.systemGray5))
                                        .foregroundStyle(selectedFilter == filter ? Color.white : Color.black)
                                        .clipShape(Capsule())
                                }
                            }
                        }
                        .padding(.horizontal)
                    }

                    if filteredNotes.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "note.text")
                                .font(.system(size: 40))
                                .foregroundStyle(Color(.systemGray3))

                            Text(model.notes.isEmpty ? "No notes yet" : "No notes in this category")
                                .font(.headline)
                                .foregroundStyle(.gray)

                            Text(
                                model.notes.isEmpty
                                ? "Add your first study goal or reminder above."
                                : "Try a different filter, or add a new note."
                            )
                            .font(.caption)
                            .foregroundStyle(Color(.systemGray3))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 30)
                    } else {
                        VStack(spacing: 12) {
                            ForEach(filteredNotes, id: \.id) { note in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack {
                                        Text(note.tag)
                                            .font(.caption2)
                                            .fontWeight(.bold)
                                            .padding(.horizontal, 8)
                                            .padding(.vertical, 4)
                                            .background(Color.burgundy.opacity(0.15))
                                            .foregroundStyle(Color.burgundy)
                                            .clipShape(RoundedRectangle(cornerRadius: 8))

                                        Spacer()

                                        Text(note.dateText)
                                            .font(.caption2)
                                            .foregroundStyle(.gray)

                                        Button {
                                            model.toggleNote(note)
                                        } label: {
                                            Image(systemName: note.isCompleted ? "checkmark.circle.fill" : "checkmark.circle")
                                                .font(.title3)
                                                .foregroundStyle(note.isCompleted ? Color.green : Color(.systemGray4))
                                        }

                                        Button {
                                            model.deleteNote(note)
                                        } label: {
                                            Image(systemName: "trash")
                                                .font(.caption)
                                                .foregroundStyle(Color.red.opacity(0.8))
                                                .padding(.leading, 4)
                                        }
                                    }

                                    Text(note.title)
                                        .font(.headline)
                                        .strikethrough(note.isCompleted)
                                        .foregroundStyle(note.isCompleted ? Color.gray : Color.primary)

                                    Text(note.subtitle)
                                        .font(.caption)
                                        .foregroundStyle(.gray)
                                        .lineLimit(2)
                                }
                                .padding()
                                .background(Color.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .shadow(color: Color.black.opacity(0.02), radius: 3, x: 0, y: 2)
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.vertical)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}
