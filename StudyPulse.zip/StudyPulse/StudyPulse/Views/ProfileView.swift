import SwiftUI

struct ProfileView: View {

    var model: StudyPulseModel

    @Environment(\.dismiss) private var dismiss

    @State private var inputUsername = ""

    var body: some View {

        NavigationStack {

            VStack(spacing: 20) {

                if model.isLoggedIn {

                    Image(
                        systemName:
                            "person.crop.circle.fill"
                    )
                    .resizable()
                    .frame(
                        width: 80,
                        height: 80
                    )
                    .foregroundStyle(Color.burgundy)

                    Text(
                        "Welcome back, \(model.username)!"
                    )
                    .font(.title2)
                    .fontWeight(.bold)

                    Button {

                        model.logout()

                    } label: {

                        Text("Log Out")
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(.red)
                            .clipShape(
                                RoundedRectangle(
                                    cornerRadius: 12
                                )
                            )
                    }
                    .padding(.horizontal)

                }

                else {

                    Image(
                        systemName:
                            "person.badge.key.fill"
                    )
                    .resizable()
                    .frame(
                        width: 70,
                        height: 70
                    )
                    .foregroundStyle(Color.burgundy)
                    .padding(.bottom, 10)

                    Text("Log In")
                        .font(.title2)
                        .fontWeight(.bold)

                    TextField(
                        "Username...",
                        text: $inputUsername
                    )
                    .padding()
                    .background(
                        Color(.systemGray6)
                    )
                    .clipShape(
                        RoundedRectangle(
                            cornerRadius: 10
                        )
                    )
                    .padding(.horizontal)

                    Button {

                        model.login(
                            username: inputUsername
                        )

                    } label: {

                        Text("Log In")
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.burgundy)
                            .clipShape(
                                RoundedRectangle(
                                    cornerRadius: 12
                                )
                            )
                    }
                    .padding(.horizontal)
                }

                Spacer()
            }
            .padding(.top, 40)
            .navigationTitle("Account")
            .navigationBarTitleDisplayMode(.inline)

            .toolbar {

                ToolbarItem(
                    placement: .topBarTrailing
                ) {

                    Button("Close") {
                        dismiss()
                    }
                }
            }
        }
    }
}
