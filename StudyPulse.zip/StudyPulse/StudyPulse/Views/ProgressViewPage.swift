import SwiftUI

struct ProgressViewPage: View {

    var model: StudyPulseModel

    @Binding var showProfileSheet: Bool

    var completedPercentage: Double {

        guard !model.habits.isEmpty else {
            return 0
        }

        let completed = model.habits.filter {
            $0.isCompleted
        }.count

        return Double(completed) / Double(model.habits.count)
    }

    var body: some View {

        NavigationStack {

            ScrollView {

                VStack(
                    alignment: .leading,
                    spacing: 20
                ) {

                    HStack {

                        VStack(
                            alignment: .leading,
                            spacing: 2
                        ) {

                            Text("STUDYPULSE")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundStyle(.gray)

                            Text("Progress")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        }

                        Spacer()

                        HStack(spacing: 12) {

                            Button {

                                showProfileSheet = true

                            } label: {

                                Image(
                                    systemName:
                                        "person.crop.circle.fill"
                                )
                                .font(.title2)
                                .foregroundStyle(Color.burgundy)
                            }
                        }
                    }
                    .padding(.horizontal)

                    VStack {

                        HStack {

                            HStack(spacing: 6) {

                                Circle()
                                    .fill(Color.burgundy)
                                    .frame(
                                        width: 8,
                                        height: 8
                                    )

                                Text("TODAY'S ORBIT")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.gray)
                            }

                            Spacer()

                            Text(
                                "🔥 \(model.currentStreak) Days Streak"
                            )
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundStyle(.orange)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(
                                Color.orange.opacity(0.15)
                            )
                            .clipShape(
                                RoundedRectangle(
                                    cornerRadius: 12
                                )
                            )
                        }

                        ZStack {

                            Circle()
                                .stroke(
                                    Color(.systemGray5),
                                    lineWidth: 16
                                )

                            Circle()
                                .trim(
                                    from: 0,
                                    to: CGFloat(
                                        completedPercentage
                                    )
                                )
                                .stroke(
                                    Color.burgundy,
                                    style: StrokeStyle(
                                        lineWidth: 16,
                                        lineCap: .round
                                    )
                                )
                                .rotationEffect(
                                    .degrees(-90)
                                )

                            VStack {

                                Text(
                                    "\(Int(completedPercentage * 100))%"
                                )
                                .font(
                                    .system(
                                        size: 32,
                                        weight: .bold
                                    )
                                )

                                Text("Completed Today")
                                    .font(.caption)
                                    .foregroundStyle(.gray)
                            }
                        }
                        .frame(
                            width: 150,
                            height: 150
                        )
                        .padding(.vertical, 15)

                        HStack(spacing: 15) {

                            HStack {

                                Image(
                                    systemName:
                                        "checkmark.circle.fill"
                                )
                                .foregroundStyle(
                                    Color.burgundy
                                )

                                VStack(
                                    alignment: .leading
                                ) {

                                    Text(
                                        "\(model.habits.filter { $0.isCompleted }.count) / \(model.habits.count)"
                                    )
                                    .font(.headline)
                                    .fontWeight(.bold)

                                    Text("HABITS DONE")
                                        .font(.caption2)
                                        .foregroundStyle(.gray)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                Color(.systemGray6)
                            )
                            .clipShape(
                                RoundedRectangle(
                                    cornerRadius: 12
                                )
                            )

                            HStack {

                                Image(
                                    systemName:
                                        "flame.fill"
                                )
                                .foregroundStyle(.orange)

                                VStack(
                                    alignment: .leading
                                ) {

                                    Text(
                                        "\(model.currentStreak) Days"
                                    )
                                    .font(.headline)
                                    .fontWeight(.bold)

                                    Text("CURRENT STREAK")
                                        .font(.caption2)
                                        .foregroundStyle(.gray)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                Color(.systemGray6)
                            )
                            .clipShape(
                                RoundedRectangle(
                                    cornerRadius: 12
                                )
                            )
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .clipShape(
                        RoundedRectangle(
                            cornerRadius: 16
                        )
                    )
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }

            .background(
                Color(.systemGroupedBackground)
                    .ignoresSafeArea()
            )

            .toolbar(
                .hidden,
                for: .navigationBar
            )
        }
    }
}

#Preview {
    ProgressViewPage(
        model: StudyPulseModel(),
        showProfileSheet: .constant(false)
    )
}
