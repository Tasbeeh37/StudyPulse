import SwiftUI

struct TodayView: View {

    var model: StudyPulseModel

    @Binding var showProfileSheet: Bool

    @State private var newHabitTitle = ""

    var completionPercentage: Double {
        guard !model.habits.isEmpty else { return 0 }
        let completed = model.habits.filter { $0.isCompleted }.count
        return Double(completed) / Double(model.habits.count)
    }

    var completedCount: Int {
        model.habits.filter { $0.isCompleted }.count
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("STUDYPULSE")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundStyle(.gray)

                            Text(model.isLoggedIn ? "Hi, \(model.username)" : "Today")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        }

                        Spacer()

                        HStack(spacing: 12) {
                            Button {
                                showProfileSheet = true
                            } label: {
                                Image(systemName: model.isLoggedIn ? "person.circle.fill" : "person.crop.circle.fill")
                                    .font(.title2)
                                    .foregroundStyle(Color.burgundy)
                            }
                        }
                    }
                    .padding(.horizontal)

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            HStack(spacing: 4) {
                                Text("Daily Target")
                                    .fontWeight(.semibold)
                                Image(systemName: "checkmark.seal.fill")
                                    .foregroundStyle(.gray)
                            }
                            .font(.subheadline)

                            Spacer()

                            Text("🔥 \(model.currentStreak) Days")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundStyle(.orange)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(Color.orange.opacity(0.15))
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                        }

                        HStack {
                            Text("You're getting closer! 💪")
                                .font(.headline)
                                .fontWeight(.bold)
                            Spacer()
                            Text("\(Int(completionPercentage * 100))%")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundStyle(Color.burgundy)
                        }

                        ProgressView(value: completionPercentage)
                            .tint(.burgundy)

                        HStack {
                            Text("\(completedCount) of \(model.habits.count) habits completed")
                                .font(.caption)
                                .foregroundStyle(.gray)
                            Spacer()
                            Text("📈 On Track")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundStyle(.green)
                        }
                    }
                    .padding()
                    .background(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: .black.opacity(0.04), radius: 6, x: 0, y: 3)
                    .padding(.horizontal)

                    HStack {
                        Image(systemName: "square.and.pencil")
                            .foregroundStyle(.gray)

                        TextField("Enter new habit...", text: $newHabitTitle)

                        Button {
                            model.addHabit(title: newHabitTitle)
                            newHabitTitle = ""
                        } label: {
                            Image(systemName: "plus")
                                .foregroundStyle(.white)
                                .padding(10)
                                .background(Color.burgundy)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .padding(.horizontal)

                    HStack {
                        Text("TODAY'S HABITS")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundStyle(.gray)
                        Spacer()
                        Text("\(model.habits.count) items")
                            .font(.caption)
                            .foregroundStyle(.gray)
                    }
                    .padding(.horizontal)

                    if model.habits.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "checkmark.circle")
                                .font(.system(size: 40))
                                .foregroundStyle(Color(.systemGray3))
                            Text("No habits yet")
                                .font(.headline)
                                .foregroundStyle(.gray)
                            Text("Add your first habit above to get started.")
                                .font(.caption)
                                .foregroundStyle(Color(.systemGray3))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 30)
                    } else {
                        VStack(spacing: 10) {
                            ForEach(model.habits) { habit in
                                HStack {
                                    Button {
                                        model.toggleHabit(habit)
                                    } label: {
                                        Image(systemName: habit.isCompleted ? "checkmark.circle.fill" : "circle")
                                            .font(.title2)
                                            .foregroundStyle(habit.isCompleted ? .green : Color(.systemGray4))
                                    }

                                    Text(habit.title)
                                        .font(.subheadline)
                                        .strikethrough(habit.isCompleted)
                                        .foregroundStyle(habit.isCompleted ? .gray : .primary)
                                        .lineLimit(1)

                                    Spacer()

                                    Text(habit.tag)
                                        .font(.caption2)
                                        .fontWeight(.semibold)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 4)
                                        .background(Color(.systemGray5))
                                        .clipShape(RoundedRectangle(cornerRadius: 8))

                                    Button {
                                        model.deleteHabit(habit)
                                    } label: {
                                        Image(systemName: "trash")
                                            .font(.subheadline)
                                            .foregroundStyle(.red.opacity(0.8))
                                            .padding(.leading, 6)
                                    }
                                }
                                .padding()
                                .background(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .shadow(color: .black.opacity(0.02), radius: 3, x: 0, y: 2)
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.vertical)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}
